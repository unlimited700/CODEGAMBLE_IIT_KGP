<html>
<title>CODEGAMBLER</title>
<div id="header" style="background-color:#FFA500;">


 <head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/main.css">
  <script type="application/javascript">
var r = 200 , center_x = 659 , center_y = 280 ;

function draw() {
  var canvas = document.getElementById('canvas');
  if (canvas.getContext){
    var ctx = canvas.getContext('2d');

    ctx.beginPath();

	
    ctx.arc(center_x,center_y,r,0,Math.PI*2,true); // Outer circle
    ctx.fillStyle = 'blue';
    ctx.fill() ;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(center_x,center_y,3.4*r/4,0,Math.PI*2,true) ;
    ctx.fillStyle = 'yellow';
    ctx.fill() ;		
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(center_x,center_y,r/2,0,Math.PI*2,true) ;	
    ctx.fillStyle = 'green';
    ctx.fill() ;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(center_x,center_y,r/4,0,Math.PI*2,true) ;	
    ctx.fillStyle = 'red';
    ctx.fill() ;
    ctx.stroke();

  }
}

  </script>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<script src="js/jquery-1.11.1.js"></script>
<script type='text/javascript' src='js/menu_jquery.js'></script>
 </head>


<h4>Scratchpad   <a href="How_to_play.php">How to Play</a> <a href="Score.php">Score</a> 
		<a href="Rank.php">Your Rank</a>  <a href="https://www.google.com">Logout</a> 
		<a href="Contact.php">Contact</a> </h4>
<div id='cssmenu'>
<ul>
   <li class='has-sub'><a href='#'><span>File</span></a>
      <ul>
         <li><a href='#'><span>Open</span></a></li>
         <li><a href='#'><span>Save a Copy as</span></a></li>
         <li><a href='#'><span>Rename</span></a></li>
         <li><a href='#'><span>Delete</span></a></li>
         <li class='last'><a href='#'><span>Close</span></a></li>
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>Edit</span></a>
      <ul>
         <li><a href='#'><span>Open</span></a></li>
         <li><a href='#'><span>Save a Copy as</span></a></li>
         <li class='last'><a href='#'><span>Close</span></a></li>
      </ul>
   </li>
   <li class='has-sub'><a href='#'><span>CloseScratchPad</span></a>
      
   </li>
</ul>
</div>
 <body onload="draw()" style="background-color:orange;">
		<canvas id="canvas" width="1300" height="500" ></canvas>
		<center>
		<button id = "btn1" onclick="add_image(1)" ><img src="images/1.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn2" onclick="add_image(2)" ><img src="images/2.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn3" onclick="add_image(3)" ><img src="images/3.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn4" onclick="add_image(4)" ><img src="images/4.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn5" onclick="add_image(5)" ><img src="images/5.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn6" onclick="add_image(6)" ><img src="images/6.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn7" onclick="add_image(7)" ><img src="images/7.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn8" onclick="add_image(8)" ><img src="images/8.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn9" onclick="add_image(9)" ><img src="images/9.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn10" onclick="add_image(10)" ><img src="images/10.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn11" onclick="add_image(11)" ><img src="images/11.jpg" style="height:60px; width:60px;" ></button>
		<button id = "btn12" onclick="add_image(12)" ><img src="images/12.jpg" style="height:60px; width:60px;" ></button>
		</center>

 </body >
</html>