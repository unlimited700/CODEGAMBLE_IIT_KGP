<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Secure Login: Protected Page</title>
        <link rel="stylesheet" href="styles/main.css" />
    </head>
    <body>
        <?php if (login_check($mysqli) == true) : //here goes to if part when someone logs in...?>
<body>

<div id="container" style="width:1230px">

<div id="header" style="background-color:#FFA500;">
<h1 style="margin-bottom:0;" > <center>CODEGAMBLER</center></h1></div>

<div id="menu" style="background-color:#FFD700;height:500px;width:150px;float:left;">
<b>
<p>Welcome <?php echo htmlentities($_SESSION['username']); ?>!</p>
<a href = "How_to_play.html">How to Play</a> <br>
<a href = "Score.html">Score</a><br>
<a href = "Your_rank.html">Your Rank</a></br>
<a href="includes/logout.php">Logout</a><br>
<a href = "Contact.html">Contact</a><br>
</div>

<div id="content" style="background-color:#EEEEEE;height:500px;width:1080px;float:left;">
<p id = "demo" > </p>
<br> <br> <br> <br>
		<center> <button id = "bt_id" onclick = "myFunction()" > <b>Start<b>  </center> 
	
		<script>
			document.getElementById("bt_id").style.width = '150px'  ;
			document.getElementById("bt_id").style.height = '50px'  ;
			function myFunction() {
				document.getElementById("demo").innerHTML = " Welcom User! " ;
				document.location.href="Game.php";
			}
		</script>
		
		
<center> <b>Click start to join the game.<br> Make sure you logout to leave the game.<br> Click on "How to Play" to know the rules of the game. </b>
</center>
</div>

<div id="footer" style="background-color:#FFA500;clear:both;text-align:center;">
Copyright �Xtribe.com</div>

</div>

</body>



        <?php else : ?>
            <p>
                <span class="error">You are not authorized to access this page.</span> Please <a href="login.php">login</a>.
            </p>
        <?php endif; ?>
    </body>



</html>



