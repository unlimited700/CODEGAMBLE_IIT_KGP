<title>CODEGAMBLER</title>
<div id="header" style="background-color:#FFA500;">
<h1 style="margin-bottom:0;" > <center>CODEGAMBLER</center></h1></div>

 <head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/main.css">
  <script type="application/javascript">
var r = 200 , center_x = 280 , center_y = 280 ;

function generate() {
	var canvas = document.getElementById('canvas');
	if( canvas.getContext ) {
		var ctx = canvas.getContext('2d') ;
		ctx.beginPath() ;
		//ctx.arc(center_x,center_y,r,0,Math.PI*2,true); // Outer circle
		ctx.clearRect(0,0,700,580) ;
		draw() ;
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(center_x , center_y);

	//first_segment first line...
	var x1 , y1 , m;
	m = Math.random()*( Math.PI*2  ) ;
	radius = r + 20 ;
	x1 = center_x + radius*Math.cos(m) ;
	y1 = center_x + radius*Math.sin(m);
    	ctx.lineTo(x1,y1) ;

	//second line...
	var x2 , y2 ;

	if( m+.3 > Math.PI*2 ) m = m-.3 ;
	else m = m+.3 ;


	x2 = center_x + radius*Math.cos(m) ;
	y2 = center_x + radius*Math.sin(m) ;
	
	ctx.moveTo(center_x , center_y ) ;
    	ctx.lineTo(x2,y2) ;
	ctx.lineTo(x1,y1) ;

	//filling random number...
	var centroid_x = (x1+x2+center_x)/3 , centroid_y = (y1+y2+center_y)/3 ;
	var rand = parseInt(Math.random()*100 );
	while( rand < 80 ) rand = parseInt(Math.random()*100) ;
	ctx.fillText(rand, centroid_x, centroid_y);


	ctx.moveTo(center_x,center_y);	//second_segment_fist line...
	m += 1 ;
	
	x1 = center_x + radius*Math.cos(m) ;
	y1 = center_x + radius*Math.sin(m);
    	ctx.lineTo(x1,y1) ;	


	//second line...
	//changing angle by 1 (constant chage)...
	if( m+.3 > Math.PI*2 ) m = m-.3 ;
	else m = m+.3 ;

	x2 = center_x + radius*Math.cos(m) ;
	y2 = center_x + radius*Math.sin(m) ;
	

	//filling random number...
	var centroid_x = (x1+x2+center_x)/3 , centroid_y = (y1+y2+center_y)/3 ;
	var rand = parseInt(Math.random()*100 );
	while( rand > 9 ) rand = parseInt(Math.random()*100) ;
	ctx.fillText(rand, centroid_x, centroid_y);

	ctx.moveTo(center_x , center_y ) ;
    	ctx.lineTo(x2,y2) ;
	ctx.lineTo(x1,y1) ;

	ctx.moveTo(center_x,center_y);	//third_segment_fist line...
	m += 3 ;	
	x1 = center_x + radius*Math.cos(m) ;
	y1 = center_x + radius*Math.sin(m);	
    	ctx.lineTo(x1,y1) ;


	//second line...
	//changing angle by 1 (constant chage)...
	if( m+.3 > Math.PI*2 ) m = m-.3 ;
	else m = m+.3 ;

	x2 = center_x + radius*Math.cos(m) ;
	y2 = center_x + radius*Math.sin(m) ;


	//filling random number...
	var centroid_x = (x1+x2+center_x)/3 , centroid_y = (y1+y2+center_y)/3 ;
	var rand = parseInt(Math.random()*100 );
	while( rand > 9  ) rand = parseInt(Math.random()*100) ;
	ctx.fillText(rand, centroid_x, centroid_y);
	
	ctx.moveTo(center_x , center_y ) ;
    	ctx.lineTo(x2,y2) ;
	ctx.lineTo(x1,y1) ;
		ctx.stroke() ;
	}
}

function draw() {
  var canvas = document.getElementById('canvas');
  if (canvas.getContext){
    var ctx = canvas.getContext('2d');

    ctx.beginPath();

	
    ctx.arc(center_x,center_y,r,0,Math.PI*2,true); // Outer circle
    ctx.fillStyle = 'blue';
    ctx.fill() ;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(center_x,center_y,3.4*r/4,0,Math.PI*2,true) ;
    ctx.fillStyle = 'yellow';
    ctx.fill() ;		
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(center_x,center_y,r/2,0,Math.PI*2,true) ;	
    ctx.fillStyle = 'green';
    ctx.fill() ;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(center_x,center_y,r/4,0,Math.PI*2,true) ;	
    ctx.fillStyle = 'red';
    ctx.fill() ;
    ctx.stroke();

  }
}

var delete_mode = 0 ;
function add_image(p) {
	if( !delete_mode ) {
		document.getElementById("img"+p).style.display= 'inline';
		document.getElementById("img"+p).src="images/" + p +".jpg";
	}
	else document.getElementById("img"+p).style.display= 'none';

}
function delete_image() {
	delete_mode = 1 - delete_mode ;
	if( delete_mode ) document.getElementById("demo").innerHTML = "Click images to REMOVE from dashboard";
	else document.getElementById("demo").innerHTML = "Click images to ADD on dashboard";
	
}

function open_scratchpad() {
	document.location.href="scratchpad.php" ;
}
  </script>
 </head>


 <body onload="draw()" style="background-color:orange;">
<div class ="back" >
   <div>
	<div>   <canvas id="canvas" width="550" height="500" >
				
		</canvas> 
		<div class="wrapper" id="content" style="background-color: red;height:520px;width:270px;float:left;">
		<p id="demo">Click images to ADD on dashboard</p> 
		<button id = "btn1" onclick="add_image(1)" ><img src="images/1.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn2" onclick="add_image(2)" ><img src="images/2.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn3" onclick="add_image(3)" ><img src="images/3.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn4" onclick="add_image(4)" ><img src="images/4.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn5" onclick="add_image(5)" ><img src="images/5.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn6" onclick="add_image(6)" ><img src="images/6.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn7" onclick="add_image(7)" ><img src="images/7.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn8" onclick="add_image(8)" ><img src="images/8.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn9" onclick="add_image(9)" ><img src="images/9.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn10" onclick="add_image(10)" ><img src="images/10.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn11" onclick="add_image(11)" ><img src="images/11.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "btn12" onclick="add_image(12)" ><img src="images/12.jpg" style="height:60px ;width:60px;" ></button>
		<button id = "send" onclick="send_img()" style="background: url(images/msg.jpg)" ></button>
		<button id = "delete" onclick="delete_image()" style="background: url(images/delete.jpg)"  ></button>
		<button id = "undo" onclick="undo()" style="background: url(images/undo.jpg)" ></button>

		<button id="Open_Scratchpad" style="font-size:20px; width:120px; height:70px"onclick="open_scratchpad()" >Open</button>
		<button id="generate" style="font-size:20px; width:100px; height:70px"onclick="generate()" >generate</button>
		</div>
		<div style="background-color: white; width:200px ; height:300px ;float:right;">
			
			<img id="img1" style="height:60px ;width:60px; display:none">
			<img id="img2" style="height:60px ;width:60px; display:none">
			<img id="img3" style="height:60px ;width:60px; display:none">
			<img id="img4" style="height:60px ;width:60px; display:none">
			<img id="img5" style="height:60px ;width:60px; display:none">
			<img id="img6" style="height:60px ;width:60px; display:none">
			<img id="img7" style="height:60px ;width:60px; display:none">
			<img id="img8" style="height:60px ;width:60px; display:none">
			<img id="img9" style="height:60px ;width:60px; display:none">
			<img id="img10" style="height:60px ;width:60px; display:none">
			<img id="img11" style="height:60px ;width:60px; display:none">
			<img id="img12" style="height:60px ;width:60px; display:none">			
		</div>
	</div>
   </div>
   <div>

   
   </div>
</div>


 </body >