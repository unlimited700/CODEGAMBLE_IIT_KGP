<!DOCTYPE html>
<html lang="en" dir="ltr" xmlns:fb="http://www.facebook.com/2008/fbml"  xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="chrome=1">
  <link href='http://fonts.googleapis.com/css?family=Quattrocento' rel='stylesheet' type='text/css'>  
  <link href='http://fonts.googleapis.com/css?family=Nunito:400,700' rel='stylesheet' type='text/css'>  
  <link href='/sites/all/themes/etslook/bootstrap/css/bootstrap.css' rel='stylesheet' type='text/css'>
  <link href='/sites/all/themes/etslook/bootstrap/css/bootstrap-responsive.css' rel='stylesheet' type='text/css'>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="pragma" content="no-cache" />
<link rel="shortcut icon" href="http://www.xtribe.eu/sites/all/themes/etslook/favicon.ico" type="image/vnd.microsoft.icon" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="cache-control" content="no-cache" />
<meta name="Generator" content="Drupal 7 (http://drupal.org)" />
<meta http-equiv="cache-control" content="max-age=0" />
  <title>Blindate (English version) | Experimental Tribe</title>
  <link type="text/css" rel="stylesheet" href="http://www.xtribe.eu/sites/default/files/css/css_pbm0lsQQJ7A7WCCIMgxLho6mI_kBNgznNUWmTWcnfoE.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.xtribe.eu/sites/default/files/css/css_aAD-dIhYnJdP407oDDFkgyA-o3AsssosAFGkTIqcbyA.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.xtribe.eu/sites/default/files/css/css__CCVpt9yuFDL0FLes5iKq0QWaJd0j3ILfy6MKBSddsI.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.xtribe.eu/sites/default/files/css/css_qP_Q1AUF3fxvDp7Gso0ucKEO88Z9D8EjWzUZW3LuQDo.css" media="all" />
<link type="text/css" rel="stylesheet" href="/sites/all/themes/etslook/bootstrap/css/bootstrap.css" media="all" />
<link type="text/css" rel="stylesheet" href="/sites/all/themes/etslook/bootstrap/css/bootstrap-responsive.css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.xtribe.eu/sites/default/files/css/css_AmsLhPB5B_Aza6GeJ3dVVejZ7OfBTnGO9i1yEBxzeb4.css" media="screen" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
window.jQuery || document.write("<script src='/sites/all/modules/jquery_update/replace/jquery/jquery.min.js'>\x3C/script>")
//--><!]]>
</script>
<script type="text/javascript" src="http://www.xtribe.eu/misc/jquery.once.js?v=1.2"></script>
<script type="text/javascript" src="http://www.xtribe.eu/misc/drupal.js?n5ket7"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.11/jquery-ui.min.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
window.jQuery.ui || document.write("<script src='/sites/all/modules/jquery_update/replace/ui/ui/minified/jquery-ui.min.js'>\x3C/script>")
//--><!]]>
</script>
<script type="text/javascript" src="http://www.xtribe.eu/misc/jquery.ba-bbq.js?v=1.2.1"></script>
<script type="text/javascript" src="http://www.xtribe.eu/modules/overlay/overlay-parent.js?v=1.0"></script>
<script type="text/javascript" src="http://www.xtribe.eu/sites/all/modules/ets/ets.js?n5ket7"></script>
<script type="text/javascript" src="http://www.xtribe.eu/sites/all/modules/ets/jslib/714/sockjs-0.3.min.js?n5ket7"></script>
<script type="text/javascript" src="http://www.xtribe.eu/sites/all/modules/ets/jslib/714/ETS/ETS.js?n5ket7"></script>
<script type="text/javascript" src="http://www.xtribe.eu/sites/all/modules/ets/jslib/714/ETS/JoinShell.js?n5ket7"></script>
<script type="text/javascript" src="/sites/all/themes/etslook/js/jquery.min.js?n5ket7"></script>
<script type="text/javascript" src="/sites/all/themes/etslook/bootstrap/js/bootstrap.js?n5ket7"></script>
<script type="text/javascript" src="/sites/all/themes/etslook/js/etslook.js?n5ket7"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"etslook","theme_token":"xPs5mPDybuAnMH-a7XPeHN6GdVhS2WiyNM7Z87TzQK0","js":{"https:\/\/ajax.googleapis.com\/ajax\/libs\/jquery\/1.5.2\/jquery.min.js":1,"0":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"https:\/\/ajax.googleapis.com\/ajax\/libs\/jqueryui\/1.8.11\/jquery-ui.min.js":1,"1":1,"misc\/jquery.ba-bbq.js":1,"modules\/overlay\/overlay-parent.js":1,"sites\/all\/modules\/ets\/ets.js":1,"sites\/all\/modules\/ets\/jslib\/714\/sockjs-0.3.min.js":1,"sites\/all\/modules\/ets\/jslib\/714\/ETS\/ETS.js":1,"sites\/all\/modules\/ets\/jslib\/714\/ETS\/JoinShell.js":1,"\/sites\/all\/themes\/etslook\/js\/jquery.min.js":1,"\/sites\/all\/themes\/etslook\/bootstrap\/js\/bootstrap.js":1,"\/sites\/all\/themes\/etslook\/js\/etslook.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"misc\/ui\/jquery.ui.core.css":1,"misc\/ui\/jquery.ui.theme.css":1,"modules\/overlay\/overlay-parent.css":1,"sites\/all\/modules\/date\/date_api\/date.css":1,"sites\/all\/modules\/date\/date_popup\/themes\/datepicker.1.7.css":1,"modules\/field\/theme\/field.css":1,"sites\/all\/modules\/logintoboggan\/logintoboggan.css":1,"sites\/all\/modules\/views\/css\/views.css":1,"sites\/all\/modules\/ckeditor\/ckeditor.css":1,"sites\/all\/modules\/ctools\/css\/ctools.css":1,"sites\/all\/modules\/ets\/css\/experiment.css":1,"\/sites\/all\/themes\/etslook\/bootstrap\/css\/bootstrap.css":1,"\/sites\/all\/themes\/etslook\/bootstrap\/css\/bootstrap-responsive.css":1,"sites\/all\/themes\/etslook\/css\/etslook.css":1}},"overlay":{"paths":{"admin":"ets\/get-position\/*\nmedia\/*\/edit\nmedia\/*\/multiedit\nmedia\/*\/delete\nmedia\/browser\nmedia\/browser\/*\noverlay\/dismiss-message\nuser\/*\/shortcuts\nadmin\nadmin\/*\nbatch\ntaxonomy\/term\/*\/edit\nuser\/*\/cancel\nuser\/*\/edit\nuser\/*\/edit\/*\ntaxonomy\/*\/translate\ntaxonomy\/*\/translate\/*","non_admin":"admin\/structure\/block\/demo\/*\nadmin\/reports\/status\/php"},"pathPrefixes":["en","it"],"ajaxCallback":"overlay-ajax"},"ets_key":"parola segreta"});
//--><!]]>
</script>
  <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body class="html not-front logged-in one-sidebar sidebar-first page-ets page-ets-exp-join page-ets-exp-join- page-ets-exp-join-45 i18n-en" >
  <div id="overlay-disable-message" class="clearfix"><h3 class="element-invisible">Options for the administrative overlay</h3><a href="/user/6428/edit?destination=ets/exp-join/45#edit-overlay-control" id="overlay-profile-link" class="overlay-exclude element-invisible">If you have problems accessing administrative pages on this site, disable the overlay on your profile page.</a> <a href="/overlay/dismiss-message?destination=ets/exp-join/45&amp;token=uu0o5MGFesxRTD_o8BMxt0_ELLRmXXhepXS_mPpMTZ0" id="overlay-dismiss-message" class="overlay-exclude element-invisible">Dismiss this message.</a></div>    <div class="navbar">
	  <div class="navbar-inner">
	    <div class="container">
		    <div class="row">
		    <div class="span11">
		    	<img src="/sites/all/themes/etslook/beta-ribbon.png" id="beta">
					<a class="brand" href="/">
					  						<img src="http://www.xtribe.eu/sites/all/themes/etslook/logo.png" alt="Home" />
					  					  
					  						<span id="site-name">Experimental Tribe</span>
					  	
					</a>
		  
		  		  <div class="region region-header">
    <div id="block-system-user-menu" class="block block-system block-menu first">

    
  <div class="content">
    <ul class="menu"><li class="first collapsed"><a href="/user">My account</a></li>
<li class="last leaf"><a href="/user/logout">Log out pradeep.joshi.564813</a></li>
</ul>  </div>
</div>
<div id="block-block-1" class="block block-block">

    <h3>experimental tribe</h3>
  
  <div class="content">
    <p>is a web platform for gaming and social computation. It helps researchers to realize web games/experiments and it let people join, while enjoying, the scientific research.</p>
  </div>
</div>
<div id="block-system-main-menu" class="block block-system block-menu">

    <h3>Main menu</h3>
  
  <div class="content">
    <ul class="menu"><li class="first leaf"><a href="/" title="">Home</a></li>
<li class="leaf"><a href="/latest-experiments" title="">Experiments</a></li>
<li class="leaf"><a href="/node/37">Developments</a></li>
<li class="leaf"><a href="/about" title="">About</a></li>
<li class="last leaf"><a href="/node/36">Credits</a></li>
</ul>  </div>
</div>
  </div>
		    </div>
		    </div>
	    </div>
	  </div>
  </div>
  
  <div id="main" class="container">
		<div class="row">

		  			
						  						 
					
		  			  <div class="region region-sidebar-first span2">
    <div id="block-system-navigation" class="block block-system block-menu first">

    
  <div class="content">
    <ul class="menu"><li class="first collapsed"><a href="/forum">Forums</a></li>
<li class="leaf"><a href="http://www.xtribe.eu/user" title="">Profile</a></li>
<li class="last leaf"><a href="/tracker">Recent content</a></li>
</ul>  </div>
</div>
  </div>
		  	  
		  
		  <div class="span9">
									<div class="page-header">
			  <h1>Blindate (English version)</h1>
			</div>
						
			
			  <div class="experiment-join">
  <h2>Waiting for the instance to start. Timeout in <span id="elapsed">(calculating...)</span></h2>
  <p id="please-wait">Please wait, user <strong id="userId"></strong>.</p>
  <p id="status"><strong id="nUsers">0</strong> people have joined so far.</a>
  <p><a href="/">Cancel</a></p>
  </div>
  
  <script>
  ;(function($) {

    var position = {required: false, latitude: 0, longitude: 0};

     
    
    $('#userId').text(6428 === 0 ? 'anonymous' : 6428);

    var eId = 45;
    
    var joinShell = new ETS.JoinShell();
  
    joinShell.setIds({eId: eId, uId: 6428, guid: '53ba41d02eb66'});

    joinShell.setPosition(position);
    
    joinShell.setChannel(new ETS.Channel('ehs.xtribe.eu', 80, "ehs"));

    joinShell.on('disconnect', function() {
      $(window).unbind('beforeunload.ets');
      if (this.channel.connected) {
        $('#status').html("The remote end hung up unexpectedly. Experiment aborted.");
        this.channel.close();
        $("#please-wait").slideUp('slow');
        ETS.Drupal.watchdog("ETS Client JOIN", "The remote end hung up unexpectedly", ETS.Drupal.WATCHDOG_WARNING);
      }
      joinShell.shutdown();
    })
  
    joinShell.on('tick', function(elapsed) {
      $('#elapsed').text(180 - elapsed);
      if (elapsed > 180) {
        joinShell.shutdown();
        $('#elapsed').text("Timeout");
        $("#please-wait").slideUp('slow');
        ETS.Drupal.watchdog("ETS Client JOIN", "Timout on join", ETS.Drupal.WATCHDOG_NOTICE);
      }
    });
    
    joinShell.on('accept', function(message) {
    });
    
    joinShell.on('status', function(message) {
      if (message.params.exception) {
        joinShell.shutdown();
        $("#status").text(message.params.exception);
        $("#please-wait").slideUp('slow');
      } else {
        $("#nUsers").text(message.params.nUsers + " out of " + message.params.nUsersMin);
      }
    })
    
    joinShell.on('error', function(error) {
      $(window).unbind('beforeunload.ets');
      joinShell.shutdown();
      if ('object' == typeof error) {
        error = error.error
      }
      $('#status').html("Sorry, an error occurred while trying to contact the server (" + error + "). <a href=''>Retry</a>");
      $("#please-wait").slideUp('slow');
      ETS.Drupal.watchdog("ETS Client JOIN", "The server reported an error: " + error, ETS.Drupal.WATCHDOG_ERROR);
    })

    joinShell.on('refuse', function(error) {
      $(window).unbind('beforeunload.ets');
      joinShell.shutdown();
      $('#elapsed').text("Aborted");
      $("#status").text(error);
      $("#please-wait").slideUp('slow');
      if (error) {
        alert("Sorry, the experiment cannot be started: " + ((typeof error == 'object' ? error.message : error)));
        ETS.Drupal.watchdog("ETS Client JOIN", "Experiment cannot be started: " + ((typeof error == 'object' ? error.message : error)), ETS.Drupal.WATCHDOG_WARNING);
      } else { // Unlikely (denotes an error in the server)
        alert("Sorry, the experiment can't be started.\nTry again in a few minutes.");
        ETS.Drupal.watchdog("ETS Client JOIN", "Experiment cannot be started (no error)", ETS.Drupal.WATCHDOG_WARNING);
      }
    });
    
    joinShell.on('start', function(data) {
      // A new instance has been created. Move the user to the perform page. 
      // Add another second of entropy trying to serialize MHS contacts
      joinShell.shutdown();
      $(window).unbind('beforeunload.ets');
      setTimeout(function() {
        location.href = ETS.Tools.themedUrl("/ets/exp-perform/" + eId + "/" + data.iId + "/dea03a6b2a");          
      }, 0|(Math.random() * 1000));
    });

    joinShell.boot();

    $(window).bind('beforeunload.ets', function(e) {
      var m = "Current experiment will be interrupted"; // Firefox will not show the warning
      if (e) {
        e.returnValue = m;
      }
      return m;
    });

  })(jQuery);

  </script>
		  </div>
		  
		  		  
		  <footer class="footer span11">
			  <div class="region region-footer">
    <div id="block-system-powered-by" class="block block-system first">

    
  <div class="content">
    <span>Powered by <a href="http://drupal.org">Drupal</a></span>  </div>
</div>
  </div>
		  </footer>
		</div>
  </div>
  </body>
</html>
