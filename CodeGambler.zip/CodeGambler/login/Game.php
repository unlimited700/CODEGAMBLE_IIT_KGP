<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
				
if (isset($_SESSION['username'] )) {				
				//document.getElementById("demo").innerHTML = " Welcome User! " ;
				//document.location.href="arena.php" ;
				//Insert email id into table track...
				// Check connection
					/*if (mysqli_connect_errno()) {
					  echo "Failed to connect to MySQL: " . mysqli_connect_error();
					}
					echo " going to insert" ;
					mysqli_query($mysqli,"INSERT INTO track VALUES ('ram')");
					echo "Tryed to insert" ;
					

					mysqli_close($mysqli);
					*/
					
					
					echo " going to insert" ;
					$x = $_SESSION['username'] ;
					if ($insert_stmt = $mysqli->prepare("INSERT INTO track (email) VALUES ('$x')")) {
						// Execute the prepared query.
					}	
            if (! $insert_stmt->execute()) {
                //header('Location: ../error.php?err=Registration failure: INSERT');
            }
				$handler = new PDO('mysql:host=localhost;dbname = phpmyadmin','unlimited700',785785);
				$handler->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
				
				$query = $handler->query('SELECT * FROM track');
				$results = $query->fetchAll(PDO::FETCH_ASSOC);
				print_r($results);
				
			
			
}
        				
		?>